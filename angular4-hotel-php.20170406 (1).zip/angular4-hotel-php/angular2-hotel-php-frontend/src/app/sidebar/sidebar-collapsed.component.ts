import {Component} from "@angular/core";

@Component({
  selector: 'sidebar-collapsed',
  styles: [`  `],
  template: `
  <ng-content></ng-content>
`,
})
export class SidebarCollapsedComponent {
}

